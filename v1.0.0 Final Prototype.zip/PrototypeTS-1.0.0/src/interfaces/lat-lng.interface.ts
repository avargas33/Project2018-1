/* Representa un objeto de coordenadas con latitud y longitud */
export interface LatLng {
    lat: number,
    lng: number
};