export interface CrimeOption{
    id: number,
    value: string,
    text: string
};