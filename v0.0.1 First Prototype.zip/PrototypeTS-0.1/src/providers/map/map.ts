import { Injectable } from '@angular/core';
import { Http } from '@angular/http';
import 'rxjs/add/operator/map';

declare var google;
@Injectable()
export class MapProvider {

  constructor(public http: Http) {}

  createMap(map, center, zoom, type){
    return new google.maps.Map(map, {
      center: new google.maps.LatLng(
        center.latitude,
        center.longitude
      ),
      zoom: zoom,
      mapTypeId: type,
      zoomControl: false,
      mapTypeControl: false,
      scaleControl: false,
      streetViewControl: false,
      rotateControl: false,
      fullscreenControl: false
    });
  }

  addMarker(map, position) {
    return new google.maps.Marker({
      map: map,
      animation: google.maps.Animation.DROP,
      position: position
    });
  }

  addInfoWindow(map, marker, content){
    google.maps.event.addListener(marker, 'click', () => {
      new google.maps.InfoWindow({
        content: content
      }).open(map, marker);
    });
  }

  createHeatMap(map, data) {
    return new google.maps.visualization.HeatmapLayer({
      data: data
    }).setMap(map);
  }

  createLatLngObj(lat, lng) {
    return new google.maps.LatLng(lat, lng);
  }

  bindEvent(map, event, callback){
    google.maps.event.addListener(map, event, callback);
  }

}
