import { Component, ViewChild, ElementRef } from '@angular/core';
import { NavController, NavParams } from 'ionic-angular';
import { configConstants } from '../../constants/config.constants';
import { guiConstants } from '../../constants/gui.constants';
import { GmapsProvider } from '../../providers/gmaps.provider';
import { CrimeFormPage } from '../crime-form/crime-form';
import { LocationProvider } from '../../providers/location.provider';

@Component({
  selector: 'page-locate-crime',
  templateUrl: 'locate-crime.html',
})
export class LocateCrimePage {

  @ViewChild(configConstants.map.htmlElementId) mapElement: ElementRef; 
  map: any;
  locationMarker : any;
  category : string;
  location : any;
  tags : any;
  
  constructor(
    public navCtrl: NavController,
    public navParams: NavParams,
    private gmapsProvider : GmapsProvider,
    private locationProvider : LocationProvider) {
      this.tags = guiConstants.locateCrime;
      this.category = this.navParams.get(configConstants.crimes.navParams.category);
      this.location = this.navParams.get(configConstants.crimes.navParams.location);
    }

  ionViewDidLoad() {
    if (this.location) {
      this.loadMap({ latitude: this.location.lat(), longitude: this.location.lng()});
      this.locationMarker = this.gmapsProvider.addMarker(this.map, this.location);
    } else {
      this.locationProvider.getLocation()
      .then(this.loadMap.bind(this))
      .catch(e => {
        var lastLocation = this.locationProvider.getLastLocation();
        this.loadMap(lastLocation ? lastLocation : configConstants.map.defaultCenter);
      });
    }
  }

  private loadMap(center) {
    this.map = this.gmapsProvider.createMap(
      this.mapElement.nativeElement, center,
      configConstants.map.locateZoom, configConstants.map.mapTypeId
    );
    this.gmapsProvider.bindEvent(this.map, 'click', this.locationSelected.bind(this));
  }

  private locationSelected(event) {
    if (this.locationMarker) {
      this.locationMarker.setMap(null);
    }
    this.locationMarker = this.gmapsProvider.addMarker(this.map, event.latLng);
  }

  locationConfirmed() {
    this.navCtrl.push(CrimeFormPage, {
      category: this.category,
      location: this.locationMarker.position
    });
  }
}