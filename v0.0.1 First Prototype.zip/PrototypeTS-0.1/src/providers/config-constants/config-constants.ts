import { Injectable } from '@angular/core';
/*
  Generated class for the ConfigConstantsProvider provider.

  See https://angular.io/docs/ts/latest/guide/dependency-injection.html
  for more info on providers and Angular DI.
*/
declare var google;

@Injectable()
export class ConfigConstantsProvider {

  private configConstants : any;
  
  baseURL : string = 'http://localhost:3000/';

  constructor() {
    this.configConstants = {
      webAPI: {
        urls: {
          crimes: this.baseURL + 'crimes'
        }
      },
      map: {
        defaultCenter: {
          latitude: 7.1297,
          longitude: -73.125769
        },
        zoom: 17,
        locateZoom: 15,
        mapTypeId: google.maps.MapTypeId.ROADMAP
      }
    };
  }

  getConstants() {
    return this.configConstants;
  }

}
