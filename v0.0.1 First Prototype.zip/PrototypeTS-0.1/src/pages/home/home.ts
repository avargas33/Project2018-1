import { Component, ViewChild, ElementRef } from '@angular/core';
import { NavController, Platform } from 'ionic-angular';
import { GuiConstantsProvider } from '../../providers/gui-constants/gui-constants';
import { ConfigConstantsProvider } from '../../providers/config-constants/config-constants';
import { MapProvider } from '../../providers/map/map';
import { HomeProvider } from './home.provider';
import { AndroidPermissions } from '@ionic-native/android-permissions';

@Component({
  selector: 'page-home',
  templateUrl: 'home.html',
  providers: [GuiConstantsProvider]
})
export class HomePage {
  
  @ViewChild('map') mapElement: ElementRef; 
  map: any;
  tags : any;
  config : any;

  constructor(public navCtrl: NavController, public GUI:GuiConstantsProvider,
  private homeProvider : HomeProvider, configConstants : ConfigConstantsProvider,
  private mapProvider : MapProvider, public platform: Platform,
  public androidPermissions : AndroidPermissions) {
      this.tags = GUI.getConstants().home;
      this.config = configConstants.getConstants();
  }

  ionViewDidLoad() {
    console.log('ion view did load');
    this.platform.ready().then(() => {
      this.androidPermissions.checkPermission(this.androidPermissions.PERMISSION.ACCESS_FINE_LOCATION).then(
        result => {
          console.log('Getting Location is allowed', result);
          this.checkLocation();
        },
        err => this.androidPermissions.requestPermission(this.androidPermissions.PERMISSION.ACCESS_FINE_LOCATION)
        .then(this.checkLocation.bind(this))
        .catch(this.logErrorAndStop.bind(this))
      );
    });
  }

  private checkLocation() {
    this.homeProvider.getLocation()
    .then(this.loadMap.bind(this))
    .catch(this.logErrorAndStop.bind(this));
  }

  private loadMap(position : any) {
    console.log('load map');
    this.map = this.mapProvider.createMap(
      this.mapElement.nativeElement, position.coords,
      this.config.map.zoom, this.config.map.mapTypeId
    );
    this.mapProvider.addMarker(this.map, this.map.getCenter());
    this.homeProvider.getCrimeData()
    .then(this.loadHeatMap.bind(this))
    .catch(this.logErrorAndStop.bind(this));
  }

  private logErrorAndStop(error) {
    console.error(error);
  }

  private loadHeatMap(crimes) {
    console.log('load heat map');
    let heatMapData = [];
    JSON.parse(crimes._body).forEach(crime => {
      heatMapData.push(
        this.mapProvider.createLatLngObj(crime.location[0], crime.location[1])
      );
    });
    this.mapProvider.createHeatMap(this.map, heatMapData);
  }
}