export interface CrimeType {
    id : number;
    name : string;
    value : string;
    gradient : Array<string>;
    data ?: Array<any>;
    markers ?: Array<any>;
    checked ?: boolean;
    heatmap ?: any;
    infoWindows ?: Array<any>;
};