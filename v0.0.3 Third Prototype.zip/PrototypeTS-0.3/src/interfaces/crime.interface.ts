export interface Crime {
    id : number;
    location: string;
    type: number;
};