
import { Injectable } from '@angular/core';
import { LoadingController, Loading, AlertOptions, AlertController} from 'ionic-angular';
import { SlicedAlertOptions } from '../interfaces/sliced-alert-options.interface';
import * as _ from 'lodash';

@Injectable()
export class UtilsProvider {
  constructor(
    private loadingCtrl : LoadingController,
    private alertCtrl : AlertController
  ) {}

  cloneObj(obj : object) : object {
    return JSON.parse(JSON.stringify(obj));
  }

  createLoader(msg) : Loading {
    return this.loadingCtrl.create({
      content: msg
    });
  }

  createAlertOpts(opts : SlicedAlertOptions, handler : () => void) : AlertOptions {
    let crimeAlertOpts = this.cloneObj(opts);
    (<any>(_.head((<AlertOptions>crimeAlertOpts).buttons))).handler = handler;
    return crimeAlertOpts;
  }

  createAlert(opts : AlertOptions) : Promise<any> {
    return this.alertCtrl.create(opts).present();
  }
}