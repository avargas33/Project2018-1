export interface LatLng {
    lat: number,
    lng: number
};