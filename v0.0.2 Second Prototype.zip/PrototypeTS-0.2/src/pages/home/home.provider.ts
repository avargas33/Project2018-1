import { Injectable } from '@angular/core';
import { Http } from '@angular/http';
import { configConstants } from '../../constants/config.constants';
import 'rxjs/add/operator/toPromise';

@Injectable()
export class HomeProvider {

  constructor(
    private http: Http
  ) {}

  getCrimeData() : Promise<any> {
    return this.http.get(configConstants.webAPI.urls.crimes.get)
      .toPromise().then(resp => JSON.parse((<any>resp)._body));
  }
}