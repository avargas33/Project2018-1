export interface SlicedAlertOptions {
    title: string,
    subTitle: string,
    buttons : Array<ButtonData>,
    enableBackdropDismiss: boolean
}

interface ButtonData {
    text: string
}