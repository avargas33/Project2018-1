import { GuiConstantsProvider } from './gui-constants';
import * as _ from "lodash";
 
let GUIConstantsProvider : any = null;

describe('GUI Constants provider', () => {
 
    beforeEach(() => {
      GUIConstantsProvider = new GuiConstantsProvider();
    });
 
    it('should return a non empty array', () => {
            let constants = GUIConstantsProvider.getConstants();
            expect(_.isObject(constants)).toBeTruthy;
            expect(constants.home).toBeDefined();
        }
    );
});