import { Component } from '@angular/core';
import { NavController, NavParams } from 'ionic-angular';
import { LocateCrimePage } from '../locate-crime/locate-crime';
import { HomePage } from '../home/home';
import { CrimeFormProvider } from './crime-form.provider';
import { configConstants } from '../../constants/config.constants';
import { guiConstants } from '../../constants/gui.constants';
import { CrimeOption } from '../../interfaces/crime-option.interface';
import { CrimeFormData } from '../../interfaces/crime-form-data.interface';
import * as _ from "lodash";

@Component({
  selector: 'page-crime-form',
  templateUrl: 'crime-form.html',
})
export class CrimeFormPage {
  form : CrimeFormData = {
    category: '',
    location: {
      lat: 0,
      lng: 0
    }
  };

  tags : any;
  crimeOptions : Array<CrimeOption>;

  constructor(public navCtrl: NavController, public navParams: NavParams,
  private crimeFormProvider : CrimeFormProvider) {
    this.tags = guiConstants.crimeForm;
    crimeFormProvider.getCrimeTypes().then(types => {
      this.crimeOptions = types;
      let category = this.navParams.get(configConstants.crimes.navParams.category);
      this.form.category = category ? category : _.head(this.crimeOptions).value;
    }).catch(console.error);
    this.form.location = this.navParams.get(configConstants.crimes.navParams.location);
  }

  ionViewDidLoad() {}

  selectLocation() {
    this.navCtrl.push(LocateCrimePage, {
      category: this.form.category,
      location: this.form.location
    });
  }

  reportCrime() {
    let option = this.crimeOptions.find(crime => crime.value === this.form.category);
    this.crimeFormProvider.reportCrime(option.id, this.form.location)
    .then(data => this.navCtrl.setRoot(HomePage))
    .catch(console.error);
  }
}