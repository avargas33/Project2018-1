import { Component, ViewChild, ElementRef } from '@angular/core';
import { NavController, Loading, AlertOptions } from 'ionic-angular';
import { configConstants } from '../../constants/config.constants';
import { guiConstants } from '../../constants/gui.constants';
import { GmapsProvider } from '../../providers/gmaps.provider';
import { CrimeFormPage } from '../crime-form/crime-form';
import { LocationProvider } from '../../providers/location.provider';
import { CrimeFormProvider } from '../crime-form/crime-form.provider';
import { UtilsProvider } from '../../providers/utils.provider';

@Component({
  selector: 'page-locate-crime',
  templateUrl: 'locate-crime.html',
})
export class LocateCrimePage {

  @ViewChild(configConstants.map.htmlElementId) mapElement: ElementRef; 
  map: any;
  locationMarker : any;
  category : string;
  location : any;
  tags : any;
  icon : any;
  loadingMap : Loading;
  locationAlertOpts : AlertOptions;
  
  constructor(
    public navCtrl: NavController,
    private gmapsProvider : GmapsProvider,
    private locationProvider : LocationProvider,
    private crimeFormProvider : CrimeFormProvider,
    private utils : UtilsProvider) {
      this.tags = guiConstants.locateCrime;
      this.location = this.crimeFormProvider.getLocation();
      this.icon = this.crimeFormProvider.getCrimeTypeIcon(this.crimeFormProvider.getCrimeType());
      this.locationAlertOpts = this.utils.createAlertOpts(guiConstants.alert.error.location, () => {
        this.navCtrl.setRoot(CrimeFormPage);
      });
    }

  ionViewDidEnter() {
    this.loadingMap = this.utils.createLoader(guiConstants.loading.msg.location);
    this.loadingMap.present();
    this.locationProvider.getLocation().then(this.loadMap.bind(this))
    .catch(e => {
      let lastLocation = this.locationProvider.getLastLocation();
      lastLocation ? this.loadMap(lastLocation) : this.utils.createAlert(this.locationAlertOpts);
    });
  }

  private loadMap(devicePosition) {
    let center = this.location ?
      { latitude: this.location.lat(), longitude: this.location.lng()} : devicePosition;
    this.map = this.gmapsProvider.createMap(
      this.mapElement.nativeElement, center, configConstants.map.locateZoom, configConstants.map.mapTypeId
    );
    this.gmapsProvider.bindEvent(this.map, 'click', this.locationSelected.bind(this));
    this.gmapsProvider.addUserPositionMarker(this.map,
      this.gmapsProvider.createLatLngObj(devicePosition.latitude, devicePosition.longitude));
    if (this.location) {
      this.locationMarker = this.gmapsProvider.addMarker(this.map, this.location, this.icon);
    }
    this.loadingMap.dismiss();
  }

  private locationSelected(event) {
    if (this.locationMarker) {
      this.locationMarker.setMap(null);
    }
    this.locationMarker = this.gmapsProvider.addMarker(this.map, event.latLng, this.icon);
  }

  locationConfirmed() {
    this.crimeFormProvider.setLocation(this.locationMarker.position);
    this.navCtrl.setRoot(CrimeFormPage);
  }
}