

import { Geolocation, Coordinates } from '@ionic-native/geolocation';
import { Injectable } from '@angular/core';

@Injectable()
export class LocationProvider {
  private lastLocation : Coordinates;

  constructor(
    private geolocation: Geolocation
  ) {}

  getLocation() {
    return this.geolocation.getCurrentPosition()
    .then(geo => {
        this.lastLocation = geo.coords;
        return this.lastLocation;
    }).catch(console.error);
  }

  getLastLocation() {
    return this.lastLocation;
  }
}