import { Component, ViewChild, ElementRef } from '@angular/core';
import { NavController, NavParams } from 'ionic-angular';
import { GuiConstantsProvider } from '../../providers/gui-constants/gui-constants';
import { ConfigConstantsProvider } from '../../providers/config-constants/config-constants';
import { MapProvider } from '../../providers/map/map';
import { CrimeFormPage } from '../crime-form/crime-form';

@Component({
  selector: 'page-locate-crime',
  templateUrl: 'locate-crime.html',
})
export class LocateCrimePage {

  @ViewChild('map') mapElement: ElementRef; 
  map: any;
  config: any;
  located : any;
  category : string;
  location : any;
  
  constructor(
    public navCtrl: NavController,
    public navParams: NavParams,
    private configConstants : ConfigConstantsProvider,
    private mapProvider :MapProvider) {
      this.config = configConstants.getConstants();
      this.category = this.navParams.get('category');
      this.location = this.navParams.get('location');
    }

  ionViewDidLoad() {
    if (this.location) {
      this.loadMap({
        latitude: this.location.lat(),
        longitude: this.location.lng()
      });
      this.located = this.mapProvider.addMarker(this.map, this.location);
    } else {
      this.loadMap(this.config.map.defaultCenter);
    }
  }

  private loadMap(center) {
    this.map = this.mapProvider.createMap(
      this.mapElement.nativeElement, center,
      this.config.map.locateZoom, this.config.map.mapTypeId
    );
    this.mapProvider.bindEvent(this.map, 'click', this.locationSelected.bind(this));
  }

  private locationSelected(event) {
    if (this.located) {
      this.located.setMap(null);
    }
    this.located = this.mapProvider.addMarker(this.map, event.latLng);
  }

  locationConfirmed() {
    this.navCtrl.push(CrimeFormPage, {
      category: this.category,
      location: this.located.position
    });
  }
}