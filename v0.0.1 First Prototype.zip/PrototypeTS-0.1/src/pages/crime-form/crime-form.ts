import { Component } from '@angular/core';
import { NavController, NavParams } from 'ionic-angular';
import { LocateCrimePage } from '../locate-crime/locate-crime';
import { HomePage } from '../home/home';
import { CrimeFormProvider } from './crime-form.provider';

@Component({
  selector: 'page-crime-form',
  templateUrl: 'crime-form.html',
})
export class CrimeFormPage {

  form : any = {
    category: '',
    location: null 
  };

  crimeOptions : any = [{
    value: 'people',
    text: 'Hurto a Persona'
  },
  {
    value: 'vehicle',
    text: 'Hurto a Vehículo'
  },
  {
    value: 'residence',
    text: 'Hurto a Residencia'
  }];

  constructor(public navCtrl: NavController, public navParams: NavParams,
  private crimeFormProvider : CrimeFormProvider) {
    this.form.category = this.navParams.get('category') ?
    this.navParams.get('category') : 'people';
    this.form.location = this.navParams.get('location');
  }

  ionViewDidLoad() {}

  selectLocation() {
    this.navCtrl.push(LocateCrimePage, {
      category: this.form.category,
      location: this.form.location
    });
  }

  reportCrime() {
    this.crimeFormProvider.reportCrime(this.form.category, this.form.location)
    .then(data => {
      this.navCtrl.setRoot(HomePage);
    })
    .catch(console.error);
  }

}
