export const guiConstants : any = {
    home: {
      title: {
        heat: 'Mapa de Calor',
        info: 'Mapa Informativo'
      },
      reportBtnLabel: 'Reportar Crimen'
    },
    crimeForm: {
      title: 'Reportar Delito',
      intro: 'Gracias por ayudarnos a hacer la ciudad mas segura. Por favor llena los siguientes' +
      'datos para reportar una actividad delictiva.',
      selectCategoryLabel: 'Tipo de delito',
      selectLocationLabel: 'Seleccionar Ubicación',
      modifyLocationLabel: 'Modificar Ubicación',
      reportBtnLabel: 'Reportar'
    },
    locateCrime: {
      title: 'Elige la ubicación',
      selectBtnLabel: 'Seleccionar'
    },
    loading: {
      msg: {
        location: 'Buscando geolocalización del dispositivo...',
        crimes: 'Recuperando información de crímenes en el área...',
        infoMap: 'Cargando Mapa Informativo...',
        heatMap: 'Cargando Mapa de Calor...',
        ongoingChanges: 'Realizando Cambios...',
        report: 'Reportando crimen...'
      }
    },
    alert: {
      error: {
        crime: {
          title: 'API Error',
          subTitle: 'No se han podido recuperar los datos de crímenes en este momento. Por favor verifica tu conexión a internet o intenta nuevamente más tarde.',
          buttons: [{
            text: 'Reintentar'
          }],
          enableBackdropDismiss: false
        },
        location: {
          title: 'Location Error',
          subTitle: 'No se ha podido obtener la ubicación del dispositivo. Por favor verifica que el GPS se encuentre encendido e intenta nuevamente.',
          buttons: [{
            text: 'Reintentar'
          }],
          enableBackdropDismiss: false
        },
        report: {
          title: 'API Error',
          subTitle: 'Ha ocurrido un error al reportar el delito. Por favor verifica tu conexión a internet o intenta nuevamente más tarde.',
          buttons: [{
            text: 'Reintentar'
          }, {
            text: 'Cancelar'
          }],
          enableBackdropDismiss: false
        }
      },
      success: {
        report: {
          title: 'Reporte Exitoso',
          subTitle: 'Muchas gracias por tu reporte. El delito ha sido registrado correctamente en la base de datos.',
          buttons: [{
            text: 'Aceptar'
          }],
          enableBackdropDismiss: false
        }
      },
      mapTypes: {
        title: '¿Qué mapa desea mostrar?',
        button: {
          text: 'Aceptar'
        }
      },
      crimeFilter: {
        title: '¿Qué delitos desea mostrar?',
        button: {
          text: 'Aceptar'
        }
      }
    },
    mapTypes: {
      heat: {
        label: 'Mapa de Calor'
      },
      info: {
        label: 'Mapa Informativo'
      }
    },
    map: {
      userPosition: 'Tu Posición'
    }
  };