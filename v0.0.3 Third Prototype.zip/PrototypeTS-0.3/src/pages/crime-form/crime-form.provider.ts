import { Injectable } from '@angular/core';
import { Headers, Http } from '@angular/http';
import { configConstants } from '../../constants/config.constants';
import { Crime } from '../../interfaces/crime.interface';
import 'rxjs/add/operator/toPromise';
import { CrimeType } from '../../interfaces/crime-type.interface';

@Injectable()
export class CrimeFormProvider {

  localCrimeTypes : any;

  private location : any;
  private crimeType : any;

  constructor(
    private http: Http
  ) {}

  getLocation() {
    return this.location;
  }

  setLocation(location) {
    this.location = location;
  }

  getCrimeType() {
    return this.crimeType;
  }

  setCrimeType(crimeType) {
    this.crimeType = crimeType;
  }

  resetFormData() {
    this.location = null;
    this.crimeType = null;
  }

  reportCrime() : Promise<any> {
    return this.http.post(configConstants.webAPI.urls.crimes.add, {
      type: this.crimeType.id,
      location: JSON.stringify({
        lat: this.location.lat(),
        lng: this.location.lng()
      })
    }).toPromise();
  }

  getCrimeTypes() : Promise<Array<CrimeType>> {
    return this.localCrimeTypes ? Promise.resolve(this.localCrimeTypes) :
    this.http.get(configConstants.webAPI.urls.crimeTypes.get).toPromise()
    .then(resp => {
      this.localCrimeTypes = JSON.parse((<any>resp)._body).map(type => {
        let gradient = JSON.parse(type.gradient);
        type.gradient = Array.isArray(gradient) && gradient.length > 0 ? gradient : null;
        return type;
      });
      return this.localCrimeTypes;
    });
  }

  getCrimeTypeIcon(type : CrimeType) : string  {
    return configConstants.mapIconsURL + type.value + '.png';
  }
}