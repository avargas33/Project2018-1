declare var google;
const baseURL : string = 'http://ec2-52-67-61-114.sa-east-1.compute.amazonaws.com:8080/';
const assetsURL: string = './assets/';

export const configConstants : any = {
    pages: {
      home: 'Mapa de Crímenes',
      report: 'Reportar Delito'
    },
    webAPI: {
      urls: {
        crimes: {
          get: baseURL + 'crimes/all',
          add: baseURL + 'crimes/add'
        },
        crimeTypes: {
          get: baseURL + 'crimetypes/all'
        }
      }
    },
    map: {
      htmlElementId: 'map',
      defaultCenter: {
        latitude: 7.1297,
        longitude: -73.125769
      },
      zoom: 17,
      locateZoom: 15,
      mapTypeId: google.maps.MapTypeId.ROADMAP
    },
    crimes: {
      navParams: {
        category: 'category',
        location: 'location'
      }
    },
    mapTypes: {
      heat: {
        name: 'heat'
      },
      info: {
        name: 'info'
      }
    },
    mapIconsURL: assetsURL + 'img/map-icons/'
  };