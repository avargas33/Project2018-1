import { LatLng } from './lat-lng.interface';

export interface CrimeFormData{
    category: string,
    location: LatLng
};