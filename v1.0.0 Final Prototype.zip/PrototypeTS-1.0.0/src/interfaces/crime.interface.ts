/* Representa la estructura de datos que se recibe del servicio de crímenes */
export interface Crime {
    id : number;
    location: string;
    type: number;
};