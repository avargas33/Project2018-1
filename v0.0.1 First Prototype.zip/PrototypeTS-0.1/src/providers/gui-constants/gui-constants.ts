import { Injectable } from '@angular/core';
import 'rxjs/add/operator/map';

@Injectable()
export class GuiConstantsProvider {

  private guiConstants : any;

  constructor() {
    this.guiConstants = {
      home: {
        title: 'Home'
      }
    };
  }

  getConstants() {
    return this.guiConstants;
  }
}
