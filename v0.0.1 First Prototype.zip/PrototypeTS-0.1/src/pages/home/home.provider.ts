import { Injectable } from '@angular/core';
import { Geolocation } from '@ionic-native/geolocation';
import { Headers, Http } from '@angular/http';
import { ConfigConstantsProvider } from '../../providers/config-constants/config-constants';
import 'rxjs/add/operator/toPromise';

declare var google;

@Injectable()
export class HomeProvider {

  config : any;

  constructor(
    private geolocation: Geolocation,
    private http: Http,
    private configConstants : ConfigConstantsProvider
  ) {
    this.config = configConstants.getConstants();
  }

  getLocation() {
    return this.geolocation.getCurrentPosition();
  }

  getCrimeData() : Promise<any> {
    return this.http.get(this.config.webAPI.urls.crimes).toPromise();
  }
}