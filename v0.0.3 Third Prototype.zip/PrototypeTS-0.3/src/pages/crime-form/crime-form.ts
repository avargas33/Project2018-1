import { Component } from '@angular/core';
import { NavController, Loading, AlertOptions } from 'ionic-angular';
import { LocateCrimePage } from '../locate-crime/locate-crime';
import { HomePage } from '../home/home';
import { CrimeFormProvider } from './crime-form.provider';
import { UtilsProvider } from '../../providers/utils.provider';
import { guiConstants } from '../../constants/gui.constants';
import { CrimeType } from '../../interfaces/crime-type.interface';
import { CrimeFormData } from '../../interfaces/crime-form-data.interface';
import * as _ from "lodash";

@Component({
  selector: 'page-crime-form',
  templateUrl: 'crime-form.html',
})
export class CrimeFormPage {
  form : CrimeFormData = {
    category: '',
    location: {
      lat: 0,
      lng: 0
    }
  };

  tags : any;
  crimeOptions : Array<CrimeType>;
  loadingReport : Loading;
  reportAlertOpts : AlertOptions;
  successAlertOpts : AlertOptions;

  constructor(public navCtrl: NavController,
  private crimeFormProvider : CrimeFormProvider,
  private utils : UtilsProvider) {
    this.tags = guiConstants.crimeForm;
    this.reportAlertOpts = this.utils.createAlertOpts(guiConstants.alert.error.report, this.reportCrime.bind(this));
    this.successAlertOpts = this.utils.createAlertOpts(guiConstants.alert.success.report, () => {
      this.navCtrl.setRoot(HomePage);
    });
    if (navCtrl.last().name !== LocateCrimePage.name) {
      this.crimeFormProvider.resetFormData();
    }
    crimeFormProvider.getCrimeTypes().then(types => {
      this.crimeOptions = types;
      let category = this.crimeFormProvider.getCrimeType();
      this.form.category = category ? category.value : _.head(types).value;
      this.crimeFormProvider.setCrimeType(this.crimeOptions.find(opt => opt.value === this.form.category));
    }).catch(console.error);
    this.form.location = this.crimeFormProvider.getLocation();
  }

  crimeTypeSelectionChanged(selection) {
    this.crimeFormProvider.setCrimeType(selection);
  }

  selectLocation() {
    this.navCtrl.push(LocateCrimePage);
  }

  reportCrime() {
    this.loadingReport = this.utils.createLoader(guiConstants.loading.msg.report);
    this.loadingReport.present();
    this.crimeFormProvider.reportCrime()
    .then(() => { this.utils.createAlert(this.successAlertOpts); })
    .catch(err => {
      console.error(err);
      this.utils.createAlert(this.reportAlertOpts);
    }).then(data => this.loadingReport.dismiss());
  }
}