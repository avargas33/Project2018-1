import { Injectable } from '@angular/core';
import { Headers, Http } from '@angular/http';
import { configConstants } from '../../constants/config.constants';
import 'rxjs/add/operator/toPromise';

@Injectable()
export class CrimeFormProvider {
  constructor(
    private http: Http
  ) {}

  reportCrime(category : number, location: any) : Promise<any> {
    return this.http.post(configConstants.webAPI.urls.crimes.add, {
      type: category,
      location: JSON.stringify({
        lat: location.lat(),
        lng: location.lng()
      })
    }).toPromise();
  }

  getCrimeTypes() : Promise<any> {
    return this.http.get(configConstants.webAPI.urls.crimeTypes.get)
      .toPromise().then(resp => JSON.parse((<any>resp)._body));
  }
}