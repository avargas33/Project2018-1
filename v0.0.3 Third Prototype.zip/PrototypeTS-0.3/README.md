# PGPrototype
Prototype for geolocalized registration 
