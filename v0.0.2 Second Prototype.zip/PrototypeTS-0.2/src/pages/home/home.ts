import { Component, ViewChild, ElementRef } from '@angular/core';
import { NavController, Platform } from 'ionic-angular';
import { guiConstants } from '../../constants/gui.constants';
import { configConstants } from '../../constants/config.constants';
import { GmapsProvider } from '../../providers/gmaps.provider';
import { HomeProvider } from './home.provider';
import { LocationProvider } from '../../providers/location.provider';
import { AndroidPermissions } from '@ionic-native/android-permissions';
import { Coordinates } from '@ionic-native/geolocation';

@Component({
  selector: 'page-home',
  templateUrl: 'home.html'
})
export class HomePage {
  
  @ViewChild(configConstants.map.htmlElementId) mapElement: ElementRef;
  map: any;
  tags : any;

  constructor(
    public navCtrl: NavController,
    private homeProvider : HomeProvider,
    private gmapsProvider : GmapsProvider,
    public platform: Platform,
    public androidPermissions : AndroidPermissions,
    private locationProvider : LocationProvider) {
      this.tags = guiConstants.home;
  }

  ionViewDidLoad() {
    this.platform.ready().then(() => {
      this.platform.is('mobile') ?
      this.androidPermissions.checkPermission(this.androidPermissions.PERMISSION.ACCESS_FINE_LOCATION)
      .then(
        result => this.checkLocation(),
        err => this.androidPermissions.requestPermission(this.androidPermissions.PERMISSION.ACCESS_FINE_LOCATION)
        .then(this.checkLocation.bind(this))
        .catch(this.logErrorAndStop.bind(this))
      ) : this.checkLocation();
    });
  }

  private checkLocation() {
    this.locationProvider.getLocation()
    .then(this.loadMap.bind(this));
  }

  private loadMap(coords : Coordinates) {
    this.map = this.gmapsProvider.createMap(
      this.mapElement.nativeElement, coords,
      configConstants.map.zoom, configConstants.map.mapTypeId
    );
    this.gmapsProvider.addMarker(this.map, this.map.getCenter());
    this.homeProvider.getCrimeData()
    .then(this.loadHeatMap.bind(this))
    .catch(this.logErrorAndStop.bind(this));
  }

  private logErrorAndStop(error) {
    console.error(error);
  }

  private loadHeatMap(crimes) {
    this.gmapsProvider.createHeatMap(this.map,
      crimes.map(crime => { let location = JSON.parse(crime.location);
      return this.gmapsProvider.createLatLngObj(location.lat, location.lng);
    }));
  }
}