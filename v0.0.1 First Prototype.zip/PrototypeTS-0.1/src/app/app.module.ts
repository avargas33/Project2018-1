import { BrowserModule } from '@angular/platform-browser';
import { ErrorHandler, NgModule } from '@angular/core';
import { IonicApp, IonicErrorHandler, IonicModule } from 'ionic-angular';

import { MyApp } from './app.component';
import { HomePage } from '../pages/home/home';
import { CrimeFormPage } from '../pages/crime-form/crime-form';
import { LocateCrimePage } from '../pages/locate-crime/locate-crime';

import { StatusBar } from '@ionic-native/status-bar';
import { SplashScreen } from '@ionic-native/splash-screen';
import { GuiConstantsProvider } from '../providers/gui-constants/gui-constants';
import { HomeProvider } from '../pages/home/home.provider';

import { Geolocation } from '@ionic-native/geolocation';
import { ConfigConstantsProvider } from '../providers/config-constants/config-constants';
import { HttpModule } from '@angular/http';
import { MapProvider } from '../providers/map/map';
import { CrimeFormProvider } from '../pages/crime-form/crime-form.provider';

import { AndroidPermissions } from '@ionic-native/android-permissions';

@NgModule({
  declarations: [
    MyApp,
    HomePage,
    CrimeFormPage,
    LocateCrimePage
  ],
  imports: [
    HttpModule,
    BrowserModule,
    IonicModule.forRoot(MyApp),
  ],
  bootstrap: [IonicApp],
  entryComponents: [
    MyApp,
    HomePage,
    CrimeFormPage,
    LocateCrimePage
  ],
  providers: [
    StatusBar,
    SplashScreen,
    {provide: ErrorHandler, useClass: IonicErrorHandler},
    GuiConstantsProvider,
    Geolocation,
    HomeProvider,
    ConfigConstantsProvider,
    MapProvider,
    CrimeFormProvider,
    AndroidPermissions
  ]
})
export class AppModule {}
