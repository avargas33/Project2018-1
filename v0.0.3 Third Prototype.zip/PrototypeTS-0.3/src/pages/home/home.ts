import { Component, ViewChild, ElementRef } from '@angular/core';
import { NavController, Platform, Loading, AlertOptions } from 'ionic-angular';
import { guiConstants } from '../../constants/gui.constants';
import { configConstants } from '../../constants/config.constants';
import { GmapsProvider } from '../../providers/gmaps.provider';
import { HomeProvider } from './home.provider';
import { UtilsProvider } from '../../providers/utils.provider';
import { LocationProvider } from '../../providers/location.provider';
import { AndroidPermissions } from '@ionic-native/android-permissions';
import { Coordinates } from '@ionic-native/geolocation';
import { CrimeFormProvider } from '../crime-form/crime-form.provider';
import { MapType } from '../../interfaces/map-type.interface';
import { Crime } from '../../interfaces/crime.interface';
import { CrimeType } from '../../interfaces/crime-type.interface';
import { CrimeFormPage } from '../crime-form/crime-form';
import * as _ from 'lodash';

@Component({
  selector: 'page-home',
  templateUrl: 'home.html'
})
export class HomePage {
  
  @ViewChild(configConstants.map.htmlElementId) mapElement: ElementRef;
  map: any;
  tags : any;
  title : string;
  crimeAlertOpts : AlertOptions;
  locationAlertOpts : AlertOptions;
  loadingLocation : Loading;
  loadingCrimeData : Loading;
  loadingHeatMap : Loading;
  loadingInfoMap : Loading;
  loadingFilterChanges : Loading;

  crimes : Array<Crime>;
  crimeTypes : Array<CrimeType>;

  mapTypes : Array<MapType> = [];
  currentMap : MapType;
  
  userPosition : any;

  constructor(
    public navCtrl: NavController,
    private homeProvider : HomeProvider,
    private gmapsProvider : GmapsProvider,
    public platform: Platform,
    public androidPermissions : AndroidPermissions,
    private locationProvider : LocationProvider,
    private utils : UtilsProvider,
    private crimeFormProvider : CrimeFormProvider) {
      this.tags = guiConstants.home;
      this.title = this.tags.title.heat;
      this.mapTypes.push(this.createMapType(
        configConstants.mapTypes.heat.name, guiConstants.mapTypes.heat.label,
        true, this.createHeatMap.bind(this), this.destroyHeatMap.bind(this),
        this.onChangeHeatMap.bind(this)
      ));
      this.mapTypes.push(this.createMapType(
        configConstants.mapTypes.info.name, guiConstants.mapTypes.info.label,
        false, this.createInfoMap.bind(this), this.destroyInfoMap.bind(this),
        this.onChangeInfoMap.bind(this)
      ));
      this.currentMap = _.head(this.mapTypes);
      this.loadingLocation = this.utils.createLoader(guiConstants.loading.msg.location);
      this.loadingCrimeData = this.utils.createLoader(guiConstants.loading.msg.crimes);
      this.locationAlertOpts = this.utils.createAlertOpts(guiConstants.alert.error.location, () => {
        this.loadingLocation = this.utils.createLoader(guiConstants.loading.msg.location);
        this.checkLocation();
      });
      this.crimeAlertOpts = this.utils.createAlertOpts(guiConstants.alert.error.crime, () => {
        this.loadingCrimeData = this.utils.createLoader(guiConstants.loading.msg.crimes);
        this.getCrimeData();
      });
  }

  reportCrime() {
    this.navCtrl.setRoot(CrimeFormPage);
  }

  toggleMapType() {
    this.utils.createAlert({
      title: guiConstants.alert.mapTypes.title,
      inputs: this.mapTypes.map(type => {
        return {
          value: type.name,
          name: type.name,
          label: type.label,
          checked: type.checked,
          type: 'radio'
        };
      }),
      buttons: [{
        text: guiConstants.alert.mapTypes.button.text,
        handler: this.onChangeMapType.bind(this)
      }],
      enableBackdropDismiss: false
    });
  }

  toggleCrimeFilter() {
    this.utils.createAlert({
      title: guiConstants.alert.crimeFilter.title,
      inputs: this.crimeTypes.map(type => {
        return {
          name: type.name,
          label: type.name,
          value: type.value,
          disabled: type.data.length === 0,
          checked: type.checked,
          type: 'checkbox'
        }
      }),
      buttons: [{
          text: guiConstants.alert.crimeFilter.button.text,
          handler: this.onChangeCrimeFilter.bind(this)
      }],
      enableBackdropDismiss: false
    });
  }

  ionViewDidEnter() {
    this.platform.ready().then(() => {
      this.platform.is('mobile') ?
      this.androidPermissions.checkPermission(this.androidPermissions.PERMISSION.ACCESS_FINE_LOCATION)
      .then(result => this.checkLocation(),
        err => this.androidPermissions.requestPermission(this.androidPermissions.PERMISSION.ACCESS_FINE_LOCATION)
        .then(this.checkLocation.bind(this))
        .catch(this.logErrorAndStop.bind(this))
      ) : this.checkLocation();
    });
  }

  centerLocation() {
    this.map.setCenter(this.userPosition.getPosition());
  }

  updateCrimes() {
    this.loadingCrimeData = this.utils.createLoader(guiConstants.loading.msg.crimes);
    this.loadingCrimeData.present();
    this.currentMap.destroy();
    this.getCrimeData();
  }

  private checkLocation() {
    this.loadingLocation.present();
    this.locationProvider.getLocation()
    .then(this.loadMap.bind(this))
    .catch(err => this.stopLoaderAndShowError(this.loadingLocation, err, this.locationAlertOpts));
  }

  private loadMap(coords : Coordinates) {
    this.map = this.gmapsProvider.createMap(
      this.mapElement.nativeElement, coords,
      configConstants.map.zoom, configConstants.map.mapTypeId
    );
    this.userPosition = this.gmapsProvider.addUserPositionMarker(this.map,
        this.gmapsProvider.createLatLngObj(coords.latitude, coords.longitude));
    this.loadingLocation.dismiss();
    this.getCrimeData();
  }

  private getCrimeData() {
    this.loadingCrimeData.present();
    this.homeProvider.getCrimeData()
    .then(this.getCrimeDataSuccess.bind(this))
    .catch(err => this.stopLoaderAndShowError(this.loadingCrimeData, err, this.crimeAlertOpts));
  }

  private getCrimeDataSuccess(crimes : Array<Crime>) {
    this.crimes = crimes;
    this.crimeFormProvider.getCrimeTypes()
    .then(types => {
      this.crimeTypes = types.map(type => {
        let data = crimes.filter(crime => crime.type === type.id).map(
        crime => { let location = JSON.parse(crime.location);
          return this.gmapsProvider.createLatLngObj(location.lat, location.lng);
        });
        return _.extend(type, {
          data: data,
          markers: data.map(position =>
            this.gmapsProvider.addMarker(null, position, this.crimeFormProvider.getCrimeTypeIcon(type))),
          checked: data.length > 0
        });
      });
      this.loadingCrimeData.dismiss();
      this.currentMap.create();
    })
    .catch(err => this.stopLoaderAndShowError(this.loadingCrimeData, err, this.crimeAlertOpts));
  }

  private createMapType(name : string, label : string, checked : boolean,
    create : () => void, destroy : () => void, update : (changedType) => void) : MapType {
    return {
      name: name,
      label: label,
      checked: checked,
      create: create,
      destroy: destroy,
      update: update
    };
  }

  private createHeatMap() {
    this.title = this.tags.title.heat;
    this.loadingHeatMap = this.utils.createLoader(guiConstants.loading.msg.heatMap);
    this.loadingHeatMap.present();
    this.crimeTypes.filter(type => type.checked).forEach(type => {
      if (type.heatmap) {
        type.heatmap.setMap(this.map);
      } else {
        type.heatmap = this.gmapsProvider.createHeatMap(this.map, type.data, type.gradient);
      }
    });
    this.loadingHeatMap.dismiss();
  }

  private destroyHeatMap() {
    this.crimeTypes.filter(type => type.heatmap).forEach(type => {
      type.heatmap.setMap(null);
      type.heatmap = null;
    });
  }

  private onChangeHeatMap(changedType) {
    changedType.checked ? changedType.heatmap.setMap(null) : changedType.heatmap.setMap(this.map);
  }

  private createInfoMap() {
    this.title = this.tags.title.info;
    this.loadingInfoMap = this.utils.createLoader(guiConstants.loading.msg.infoMap);
    this.loadingInfoMap.present();
    this.crimeTypes.filter(type => type.checked).forEach(type => {
      type.markers.forEach(marker => marker.setMap(this.map));
      type.infoWindows = type.markers.map(marker => this.gmapsProvider.addInfoWindow(this.map, marker, type.name));
    });
    this.loadingInfoMap.dismiss();
  }

  private destroyInfoMap() {
    this.crimeTypes.filter(type => type.infoWindows && type.markers).forEach(type => {
      type.infoWindows.forEach(infoWindow => infoWindow.close());
      type.markers.forEach(marker => marker.setMap(null));
    });
  }

  private onChangeInfoMap(changedType) {
    if (changedType.checked) {
      changedType.infoWindows.forEach(infoWindow => infoWindow.close());
      changedType.markers.forEach(marker => marker.setMap(null));
    } else {
      changedType.markers.forEach(marker => marker.setMap(this.map));
      changedType.infoWindows =
        changedType.markers.map(marker => this.gmapsProvider.addInfoWindow(this.map, marker, changedType.name));
    }
  }

  private onChangeCrimeFilter(data) {
    this.loadingFilterChanges = this.utils.createLoader(guiConstants.loading.msg.ongoingChanges);
    this.loadingFilterChanges.present();
    this.crimeTypes.filter(type => {
      let nowSelected = _.some(data, selected => type.value === selected);
      return (type.checked && !nowSelected) || (nowSelected && !type.checked);
    }).forEach(changed => {
      this.currentMap.update(changed);
      changed.checked = !changed.checked;
    });
    this.loadingFilterChanges.dismiss();
  }

  private onChangeMapType(data) {
    let newMap = _.find(this.mapTypes, type => type.name === data);
    if (newMap && newMap.name !== this.currentMap.name) {
      this.currentMap.checked = false;
      this.currentMap.destroy();
      this.currentMap = newMap;
      this.currentMap.create();
      this.currentMap.checked = true;
    }
  }

  private stopLoaderAndShowError(loader : Loading, error : any, crimeAlertOpts : any) {
    loader.dismiss();
    this.utils.createAlert(crimeAlertOpts);
    this.logErrorAndStop(error);
  }

  private logErrorAndStop(error) {
    console.error(error);
  }
}