export interface MapType {
    name : string;
    label : string;
    checked : boolean;
    create : () => void;
    destroy : () => void;
    update : (changed) => void;
};