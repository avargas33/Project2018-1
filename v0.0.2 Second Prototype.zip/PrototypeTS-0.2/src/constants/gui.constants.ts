export const guiConstants : any = {
    home: {
      title: 'Home'
    },
    crimeForm: {
      title: 'Reportar Delito',
      intro: 'Gracias por ayudarnos a hacer la ciudad mas segura. Por favor llena los siguientes' +
      'datos para reportar una actividad delictiva.',
      selectCategoryLabel: 'Tipo de delito',
      selectLocationLabel: 'Seleccionar Ubicación',
      modifyLocationLabel: 'Modificar Ubicación',
      reportBtnLabel: 'Reportar'
    },
    locateCrime: {
      title: 'Elige la ubicación',
      selectBtnLabel: 'Seleccionar'
    }
  };